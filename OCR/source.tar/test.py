import time
for i in range(100):
    print('test --> {}'.format(i))
    time.sleep(10)
