import torch
from torchvision import transforms
import cv2
import numpy as np
import types
from numpy import random
from matplotlib import pyplot as plt
from gtdb import box_utils
from PIL import Image, ImageOps
import os


def intersect(box_a, box_b):
    max_xy = np.minimum(box_a[:, 2:], box_b[2:])
    min_xy = np.maximum(box_a[:, :2], box_b[:2])
    inter = np.clip((max_xy - min_xy), a_min=0, a_max=np.inf)
    return inter[:, 0] * inter[:, 1]


def jaccard_numpy(box_a, box_b):
    """Compute the jaccard overlap of two sets of boxes.  The jaccard overlap
    is simply the intersection over union of two boxes.
    E.g.:
        A ∩ B / A ∪ B = A ∩ B / (area(A) + area(B) - A ∩ B)
    Args:
        box_a: Multiple bounding boxes, Shape: [num_boxes,4]
        box_b: Single bounding box, Shape: [4]
    Return:
        jaccard overlap: Shape: [box_a.shape[0], box_a.shape[1]]
    """
    inter = intersect(box_a, box_b)
    area_a = ((box_a[:, 2]-box_a[:, 0]) *
              (box_a[:, 3]-box_a[:, 1]))  # [A,B]
    area_b = ((box_b[2]-box_b[0]) *
              (box_b[3]-box_b[1]))  # [A,B]
    union = area_a + area_b - inter
    return inter / union  # [A,B]



class Compose(object):
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, img, boxes=None, bg_img=None):
        for t in self.transforms:
            img, boxes, bg_img = t(img, boxes, bg_img)
        return img, boxes, bg_img


class ConvertFromInts(object):
    def __call__(self, image, boxes=None, bg_img=None):
        return image.astype(np.float32), boxes, bg_img

class SubtractMeans(object):
    def __init__(self, mean):
        self.mean = np.array(mean, dtype=np.float32)

    def __call__(self, image, boxes=None, bg_img=None):
        image = image.astype(np.float32)
        image -= self.mean
        return image.astype(np.float32), boxes, bg_img

class ToAbsoluteCoords(object):
    def __init__(self, window):
        self.window = window

    def __call__(self, image, boxes=None, bg_img=None):
        height, width, channels = image.shape

        boxes[:, 0] *= self.window
        boxes[:, 2] *= self.window
        boxes[:, 1] *= self.window
        boxes[:, 3] *= self.window
        return image, boxes, bg_img

class ToPercentCoords(object):
    def __init__(self, window):
        self.window = window
    def __call__(self, image, boxes=None, bg_img=None):
        height, width, channels = image.shape
        # print('penc image shape:', image.shape)
        boxes[:, 0] /= self.window
        boxes[:, 2] /= self.window
        boxes[:, 1] /= self.window
        boxes[:, 3] /= self.window

        return image, boxes, bg_img

class Expand(object):
    def __init__(self, mean):
        self.mean = mean

    def __call__(self, image, boxes, bg_img=None):
        # if random.randint(2):
        #     return image, boxes, labels
        # print('input boxes:', boxes)

        height, width, depth = image.shape
        ratio = random.uniform(1, 3)
        left = random.uniform(0, width*ratio - width)
        top = random.uniform(0, height*ratio - height)
        expand_image = np.ones((int(height*ratio), int(width*ratio), depth),dtype=image.dtype) * 255
        # expand_image[:, :, :] = self.mean
        expand_image[int(top):int(top + height),
                     int(left):int(left + width)] = image.copy()
        # image = expand_image
        boxes = boxes.copy()
        boxes[:, :2] += (int(left), int(top))
        boxes[:, 2:] += (int(left), int(top))

        # print('out put boxes:', boxes)
        return expand_image, boxes, bg_img

class Mask2Windows(object):
    def __init__(self, window):
        self.window = window

    def __call__(self, image, boxes=None,bg_img=None):
        win_img = np.full((self.window, self.window, image.shape[2]), 255)
        # if random.randint(3) == 0:
        win_img[0:image.shape[0],0:image.shape[1],:] = image.copy()
        # else:
        #     # 原图在window上面随机偏移位置
        #     xl = random.randint(image.shape[1])
        #     yl = random.randint(image.shape[0])
        #     win_img[yl:yl+image.shape[0], xl:xl+image.shape[1],:] = image.copy()
        #     boxes = boxes.copy()
        #     boxes[:,(0,2)] += xl
        #     boxes[:,(1,3)] += yl
        return win_img, boxes, bg_img

class Resize(object):
    def __init__(self, size=300):
        self.size = size

    def __call__(self, image, boxes=None, bg_img=None):
        # print('resize img shape:', image.shape)
        image = cv2.resize(image.copy(), (self.size,self.size), interpolation=cv2.INTER_NEAREST)
        return image, boxes, bg_img

class RandomSize(object):
    def __init__(self, min_radio=0.8, max_radio=1):
        self.min_radio = min_radio
        self.max_radio = max_radio


    def __call__(self, image,boxes=None, bg_img=None):
        if random.randint(2):
            radio = random.uniform(self.min_radio, self.max_radio)
            # radio = 0.999
            height, width, _ = image.shape
            image = cv2.resize(image.copy(), (int(width*radio),int(height * radio)), interpolation=cv2.INTER_NEAREST)
            boxes = boxes * radio
        return image,boxes, bg_img


# 混合字符图片，如有背景图片，则将其与背景图片进行混合
class MixAlphaImage(object):
    def __init__(self):
        pass

    def __call__(self, images, boxes=None, bg_img=None):
        return images[0], boxes, bg_img


class GTDBTransform(object):
    def __init__(self, window=1200, size=300, mean=(104, 117, 123)):
        self.mean = mean
        self.size = size
        self.window = window
        self.augment = Compose([
            MixAlphaImage(),
            ToAbsoluteCoords(window=self.window),  # ToAbsoluteCoords 转成绝对坐标，生成的box进行了缩放
            Mask2Windows(window=self.window), # 将图片粘贴到1200*1200窗口大小的坐标上面
            ConvertFromInts(),
            ToPercentCoords(window=self.window),  # 与ToAbsoluteCoords对应，将target 恢复成x1/width, x2/width, y1/height, y2/height
            Resize(self.size)   # 将变换后图片转成 size * size
        ])

    def __call__(self, img, boxes, bg_img):
        return self.augment(img, boxes,bg_img)
